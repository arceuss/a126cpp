#pragma once

#include "network/Packet.h"

// Packet39 - matches Java Packet39.java exactly
// Attach Entity packet - server to client (0x27)
class Packet39 : public Packet {
public:
	int_t field_6365_a;  // Entity ID
	int_t field_6364_b;  // Vehicle ID
	
	Packet39();
	
	void readPacketData(SocketInputStream& in) override;
	void writePacketData(SocketOutputStream& out) override;
	void processPacket(NetHandler* handler) override;
	int getPacketSize() override;
	int getPacketId() const override;
};
