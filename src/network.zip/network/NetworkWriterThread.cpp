#include "network/NetworkWriterThread.h"
#include "network/NetworkManager.h"
#include <chrono>
#include <thread>
#include <stdexcept>
#include <iostream>

NetworkWriterThread::NetworkWriterThread(NetworkManager* nm, const jstring& name)
	: netManager(nm)
	, threadName(name)
{
}

void NetworkWriterThread::run()
{
	// Java: Object var1 = NetworkManager.threadSyncObject;
	//       synchronized(var1) {
	//           ++NetworkManager.numWriteThreads;
	//       }
	{
		std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
		++NetworkManager::numWriteThreads;
	}
	
	bool var2 = false;  // Java: boolean var2;
	
	// Java: while(true) {
	while (true)
	{
		var2 = false;
		bool var20 = false;  // Java: boolean var20 = false;
		
		try
		{
			var20 = true;
			var2 = true;
			
			// Java: if(!NetworkManager.isRunning(this.netManager)) {
			if (!NetworkManager::isRunning(netManager))
			{
				var2 = false;
				var20 = false;
				break;  // Exit while loop
			}
			
			// Java: while(true) {
			//           if(!NetworkManager.sendNetworkPacket(this.netManager)) {
			//               try {
			//                   sleep(100L);
			//               } catch (InterruptedException var25) {
			//               }
			//
			//               try {
			//                   if(NetworkManager.func_28140_f(this.netManager) != null) {
			//                       NetworkManager.func_28140_f(this.netManager).flush();
			//                       var20 = false;
			//                   } else {
			//                       var20 = false;
			//                   }
			//               } catch (IOException var27) {
			//                   if(!NetworkManager.func_28138_e(this.netManager)) {
			//                       NetworkManager.func_30005_a(this.netManager, var27);
			//                   }
			//
			//                   var27.printStackTrace();
			//                   var20 = false;
			//               }
			//               break;
			//           }
			//       }
			while (true)
			{
				if (!NetworkManager::sendNetworkPacket(netManager))
				{
					// Java: sleep(100L);
					try
					{
						std::this_thread::sleep_for(std::chrono::milliseconds(100));
					}
					catch (...)
					{
						// Ignore interruption
					}
					
					// Java: try { if(NetworkManager.func_28140_f(this.netManager) != null) { ... flush(); ... } }
					try
					{
						SocketOutputStream* out = NetworkManager::func_28140_f(netManager);
						if (out != nullptr)
						{
							out->flush();
						}
						var20 = false;
					}
					catch (const std::exception& e)
					{
						// Java: if(!NetworkManager.func_28138_e(this.netManager)) {
						if (!NetworkManager::func_28138_e(netManager))
						{
							// Java: NetworkManager.func_30005_a(this.netManager, var27);
							NetworkManager::func_30005_a(netManager, e);
						}
						
						// Java: var27.printStackTrace();
						std::cerr << "NetworkWriterThread exception: " << e.what() << std::endl;
						var20 = false;
					}
					break;
				}
			}
		}
		catch (...)
		{
			// Java: catch block for exception handling in outer try
		}
		
		// Java: finally {
		//           if(var20) {
		//               if(var2) {
		//                   Object var8 = NetworkManager.threadSyncObject;
		//                   synchronized(var8) {
		//                       --NetworkManager.numWriteThreads;
		//                   }
		//               }
		//           }
		//       }
		// In C++, we use RAII - decrement happens at end of scope if var2 was set
		bool decrementNow = false;
		if (var20 && var2)
		{
			decrementNow = true;
			{
				std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
				--NetworkManager::numWriteThreads;
			}
		}
		
		// Java: if(var2) {
		//           var3 = NetworkManager.threadSyncObject;
		//           synchronized(var3) {
		//               --NetworkManager.numWriteThreads;
		//           }
		//       }
		if (var2 && !decrementNow)
		{
			{
				std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
				--NetworkManager::numWriteThreads;
			}
		}
		
		if (!NetworkManager::isRunning(netManager))
		{
			break;
		}
	}
	
	// Java: if(var2) {
	//           var3 = NetworkManager.threadSyncObject;
	//           synchronized(var3) {
	//               --NetworkManager.numWriteThreads;
	//           }
	//       }
	if (var2)
	{
		{
			std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
			--NetworkManager::numWriteThreads;
		}
	}
	
	// Java: var1 = NetworkManager.threadSyncObject;
	//       synchronized(var1) {
	//           --NetworkManager.numWriteThreads;
	//       }
	{
		std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
		--NetworkManager::numWriteThreads;
	}
}
