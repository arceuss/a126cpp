#include "network/Packet51MapChunk.h"
#include "network/NetHandler.h"
#include <zlib.h>
#include <stdexcept>
#include <cstddef>

Packet51MapChunk::Packet51MapChunk()
	: xPosition(0)
	, yPosition(0)
	, zPosition(0)
	, xSize(0)
	, ySize(0)
	, zSize(0)
	, chunkSize(0)
{
	// Java: this.isChunkDataPacket = true;
	this->isChunkDataPacket = true;
}

void Packet51MapChunk::readPacketData(SocketInputStream& in)
{
	// Java: EXACT ORDER - CRITICAL for byte sequence
	// this.xPosition = var1.readInt();
	this->xPosition = in.readInt();
	
	// this.yPosition = var1.readShort();
	this->yPosition = in.readShort();
	
	// this.zPosition = var1.readInt();
	this->zPosition = in.readInt();
	
	// this.xSize = var1.read() + 1;
	this->xSize = static_cast<byte_t>(in.read() & 0xFF) + 1;
	
	// this.ySize = var1.read() + 1;
	this->ySize = static_cast<byte_t>(in.read() & 0xFF) + 1;
	
	// this.zSize = var1.read() + 1;
	this->zSize = static_cast<byte_t>(in.read() & 0xFF) + 1;
	
	// int var2 = var1.readInt();
	int_t compressedSize = in.readInt();
	
	// byte[] var3 = new byte[var2];
	std::vector<byte_t> compressedData(compressedSize);
	
	// var1.readFully(var3);
	in.readFully(compressedData.data(), compressedSize);
	
	// this.chunk = new byte[this.xSize * this.ySize * this.zSize * 5 / 2];
	int_t decompressedSize = this->xSize * this->ySize * this->zSize * 5 / 2;
	this->chunk.resize(decompressedSize);
	
	// Inflater var4 = new Inflater();
	z_stream zs;
	zs.zalloc = Z_NULL;
	zs.zfree = Z_NULL;
	zs.opaque = Z_NULL;
	zs.avail_in = 0;
	zs.next_in = Z_NULL;
	
	// var4.setInput(var3);
	int ret = inflateInit(&zs);
	if (ret != Z_OK)
	{
		throw std::runtime_error("Failed to initialize zlib inflater");
	}
	
	zs.avail_in = static_cast<uInt>(compressedSize);
	zs.next_in = reinterpret_cast<Bytef*>(compressedData.data());
	zs.avail_out = static_cast<uInt>(decompressedSize);
	zs.next_out = reinterpret_cast<Bytef*>(this->chunk.data());
	
	// try {
	//     var4.inflate(this.chunk);
	// } catch (DataFormatException var9) {
	//     throw new IOException("Bad compressed data format");
	// } finally {
	//     var4.end();
	// }
	ret = inflate(&zs, Z_FINISH);
	if (ret != Z_STREAM_END && ret != Z_OK)
	{
		inflateEnd(&zs);
		throw std::runtime_error("Bad compressed data format");
	}
	
	inflateEnd(&zs);
	
	// Store compressed size for writing (this is the size of compressed data we received)
	this->chunkSize = compressedSize;
}

void Packet51MapChunk::writePacketData(SocketOutputStream& out)
{
	// Java: EXACT ORDER - CRITICAL for byte sequence
	// var1.writeInt(this.xPosition);
	out.writeInt(this->xPosition);
	
	// var1.writeShort(this.yPosition);
	out.writeShort(this->yPosition);
	
	// var1.writeInt(this.zPosition);
	out.writeInt(this->zPosition);
	
	// var1.write(this.xSize - 1);
	out.writeByte(this->xSize - 1);
	
	// var1.write(this.ySize - 1);
	out.writeByte(this->ySize - 1);
	
	// var1.write(this.zSize - 1);
	out.writeByte(this->zSize - 1);
	
	// Java: var1.writeInt(this.chunkSize);
	// Note: chunkSize must be set before calling writePacketData
	// If chunk contains decompressed data, we need to compress it first
	// For now, assume chunkSize is already set correctly
	out.writeInt(this->chunkSize);
	
	// Java: var1.write(this.chunk, 0, this.chunkSize);
	// Write compressed chunk data
	if (this->chunkSize > 0 && this->chunkSize <= static_cast<int_t>(this->chunk.size()))
	{
		out.write(this->chunk.data(), this->chunkSize);
	}
}

void Packet51MapChunk::processPacket(NetHandler* handler)
{
	// Java: var1.handleMapChunk(this);
	handler->handleMapChunk(this);
}

int Packet51MapChunk::getPacketSize()
{
	// Java: return 17 + this.chunkSize;
	// int (4) + short (2) + int (4) + byte (1) + byte (1) + byte (1) + int (4) = 17
	return 17 + static_cast<int>(this->chunkSize);
}

int Packet51MapChunk::getPacketId() const
{
	return 51;
}
