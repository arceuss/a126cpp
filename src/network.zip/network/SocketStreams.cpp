#include "network/SocketStreams.h"
#include "java/String.h"
#include <stdexcept>
#include <iostream>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#endif

// ============================================================================
// SocketInputStream - matches Java DataInputStream exactly
// ============================================================================

SocketInputStream::SocketInputStream(SocketHandle sock)
	: socket(sock)
	, readBuffer(4096)
	, readBufferPos(0)
{
	if (socket == INVALID_SOCKET_HANDLE)
	{
		throw std::runtime_error("Invalid socket handle");
	}
}

SocketInputStream::~SocketInputStream()
{
	close();
}

int SocketInputStream::read()
{
	byte_t b;
	if (readBufferPos < readBuffer.size())
	{
		// Refill buffer if needed
		if (readBufferPos == 0)
		{
			readFully(readBuffer.data(), 1);
			b = readBuffer[0];
		}
		else
		{
			b = readBuffer[readBufferPos++];
		}
		return static_cast<int>(b) & 0xFF;
	}
	
	// Read single byte directly
#ifdef _WIN32
	int result = recv(socket, reinterpret_cast<char*>(&b), 1, 0);
#else
	ssize_t result = ::recv(socket, &b, 1, 0);
#endif
	
	if (result <= 0)
	{
		return -1;  // EOF
	}
	
	return static_cast<int>(b) & 0xFF;
}

void SocketInputStream::readFully(byte_t* buf, size_t len)
{
	size_t totalRead = 0;
	while (totalRead < len)
	{
#ifdef _WIN32
		int bytesRead = recv(socket, reinterpret_cast<char*>(buf + totalRead), static_cast<int>(len - totalRead), 0);
#else
		ssize_t bytesRead = ::recv(socket, buf + totalRead, len - totalRead, 0);
#endif
		
		if (bytesRead <= 0)
		{
			throw std::runtime_error("End of stream reached");
		}
		
		totalRead += bytesRead;
	}
}

byte_t SocketInputStream::readByte()
{
	byte_t b;
	readFully(&b, 1);
	return b;
}

short_t SocketInputStream::readShort()
{
	byte_t bytes[2];
	readFully(bytes, 2);
	// Java DataInputStream uses big-endian (network byte order)
	return static_cast<short_t>((static_cast<uint_t>(bytes[0]) << 8) | (static_cast<uint_t>(bytes[1]) & 0xFF));
}

int_t SocketInputStream::readInt()
{
	byte_t bytes[4];
	readFully(bytes, 4);
	// Java DataInputStream uses big-endian (network byte order)
	return static_cast<int_t>(
		(static_cast<ulong_t>(bytes[0]) << 24) |
		(static_cast<ulong_t>(bytes[1] & 0xFF) << 16) |
		(static_cast<ulong_t>(bytes[2] & 0xFF) << 8) |
		(static_cast<ulong_t>(bytes[3] & 0xFF))
	);
}

long_t SocketInputStream::readLong()
{
	byte_t bytes[8];
	readFully(bytes, 8);
	// Java DataInputStream uses big-endian (network byte order)
	return static_cast<long_t>(
		(static_cast<ulong_t>(bytes[0]) << 56) |
		(static_cast<ulong_t>(bytes[1] & 0xFF) << 48) |
		(static_cast<ulong_t>(bytes[2] & 0xFF) << 40) |
		(static_cast<ulong_t>(bytes[3] & 0xFF) << 32) |
		(static_cast<ulong_t>(bytes[4] & 0xFF) << 24) |
		(static_cast<ulong_t>(bytes[5] & 0xFF) << 16) |
		(static_cast<ulong_t>(bytes[6] & 0xFF) << 8) |
		(static_cast<ulong_t>(bytes[7] & 0xFF))
	);
}

float SocketInputStream::readFloat()
{
	int_t bits = readInt();
	return *reinterpret_cast<float*>(&bits);  // Java Float.intBitsToFloat
}

double SocketInputStream::readDouble()
{
	long_t bits = readLong();
	return *reinterpret_cast<double*>(&bits);  // Java Double.longBitsToDouble
}

jstring SocketInputStream::readString(int maxLength)
{
	// Java Packet.readString: reads short length, then UTF-16 chars
	short_t length = readShort();
	if (length < 0)
	{
		throw std::runtime_error("Received string length is less than zero");
	}
	if (length > maxLength)
	{
		throw std::runtime_error("Received string length longer than maximum allowed");
	}
	
	if (length == 0)
	{
		return u"";
	}
	
	// Read UTF-16 characters (Java uses char which is 16-bit)
	std::vector<ushort_t> chars(length);
	for (int i = 0; i < length; ++i)
	{
		chars[i] = readShort();  // Java char is 16-bit, read as short
	}
	
	return jstring(reinterpret_cast<const char16_t*>(chars.data()), length);
}

bool SocketInputStream::readBoolean()
{
	return readByte() != 0;
}

void SocketInputStream::close()
{
	// Socket is closed by NetworkManager, not here
}

// ============================================================================
// SocketOutputStream - matches Java DataOutputStream/BufferedOutputStream exactly
// ============================================================================

SocketOutputStream::SocketOutputStream(SocketHandle sock)
	: socket(sock)
	, writeBuffer(BUFFER_SIZE)
	, writeBufferPos(0)
{
	if (socket == INVALID_SOCKET_HANDLE)
	{
		throw std::runtime_error("Invalid socket handle");
	}
}

SocketOutputStream::~SocketOutputStream()
{
	flush();
	close();
}

void SocketOutputStream::write(int b)
{
	byte_t byte = static_cast<byte_t>(b);
	write(&byte, 1);
}

void SocketOutputStream::write(const byte_t* buf, size_t len)
{
	// BufferedOutputStream: write to buffer, flush when full
	size_t written = 0;
	while (written < len)
	{
		// Find how much space is in buffer
		size_t available = writeBuffer.size() - writeBufferPos;
		if (available == 0)
		{
			flush();  // Buffer full, flush it
			available = writeBuffer.size();
		}
		
		size_t toWrite = (len - written < available) ? (len - written) : available;
		std::memcpy(writeBuffer.data() + writeBufferPos, buf + written, toWrite);
		writeBufferPos += toWrite;
		written += toWrite;
	}
}

void SocketOutputStream::writeByte(byte_t b)
{
	write(&b, 1);
}

void SocketOutputStream::writeShort(short_t s)
{
	// Java DataOutputStream uses big-endian (network byte order)
	byte_t bytes[2];
	bytes[0] = static_cast<byte_t>((s >> 8) & 0xFF);
	bytes[1] = static_cast<byte_t>(s & 0xFF);
	write(bytes, 2);
}

void SocketOutputStream::writeInt(int_t i)
{
	// Java DataOutputStream uses big-endian (network byte order)
	byte_t bytes[4];
	bytes[0] = static_cast<byte_t>((i >> 24) & 0xFF);
	bytes[1] = static_cast<byte_t>((i >> 16) & 0xFF);
	bytes[2] = static_cast<byte_t>((i >> 8) & 0xFF);
	bytes[3] = static_cast<byte_t>(i & 0xFF);
	write(bytes, 4);
}

void SocketOutputStream::writeLong(long_t l)
{
	// Java DataOutputStream uses big-endian (network byte order)
	byte_t bytes[8];
	bytes[0] = static_cast<byte_t>((l >> 56) & 0xFF);
	bytes[1] = static_cast<byte_t>((l >> 48) & 0xFF);
	bytes[2] = static_cast<byte_t>((l >> 40) & 0xFF);
	bytes[3] = static_cast<byte_t>((l >> 32) & 0xFF);
	bytes[4] = static_cast<byte_t>((l >> 24) & 0xFF);
	bytes[5] = static_cast<byte_t>((l >> 16) & 0xFF);
	bytes[6] = static_cast<byte_t>((l >> 8) & 0xFF);
	bytes[7] = static_cast<byte_t>(l & 0xFF);
	write(bytes, 8);
}

void SocketOutputStream::writeFloat(float f)
{
	int_t bits = *reinterpret_cast<int_t*>(&f);  // Java Float.floatToIntBits
	writeInt(bits);
}

void SocketOutputStream::writeDouble(double d)
{
	long_t bits = *reinterpret_cast<long_t*>(&d);  // Java Double.doubleToLongBits
	writeLong(bits);
}

void SocketOutputStream::writeString(const jstring& str, int maxLength)
{
	// Java Packet.writeString: writes short length, then UTF-16 chars
	if (str.length() > maxLength)
	{
		throw std::runtime_error("String too big");
	}
	
	writeShort(static_cast<short_t>(str.length()));
	
	// Write UTF-16 characters (Java uses char which is 16-bit)
	const char16_t* chars = str.c_str();
	for (size_t i = 0; i < str.length(); ++i)
	{
		writeShort(static_cast<short_t>(chars[i]));  // Java char is 16-bit
	}
}

void SocketOutputStream::writeBoolean(bool b)
{
	writeByte(b ? 1 : 0);
}

void SocketOutputStream::flush()
{
	if (writeBufferPos > 0)
	{
		size_t totalSent = 0;
		while (totalSent < writeBufferPos)
		{
#ifdef _WIN32
			int sent = send(socket, reinterpret_cast<const char*>(writeBuffer.data() + totalSent), 
			                static_cast<int>(writeBufferPos - totalSent), 0);
#else
			ssize_t sent = ::send(socket, writeBuffer.data() + totalSent, writeBufferPos - totalSent, 0);
#endif
			
			if (sent <= 0)
			{
				throw std::runtime_error("Failed to send data");
			}
			
			totalSent += sent;
		}
		writeBufferPos = 0;
	}
}

void SocketOutputStream::close()
{
	// Socket is closed by NetworkManager, not here
}
