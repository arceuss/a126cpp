#include "network/NetworkReaderThread.h"
#include "network/NetworkManager.h"
#include <chrono>
#include <thread>

NetworkReaderThread::NetworkReaderThread(NetworkManager* nm, const jstring& name)
	: netManager(nm)
	, threadName(name)
{
}

void NetworkReaderThread::run()
{
	// Java: Object var1 = NetworkManager.threadSyncObject;
	//       synchronized(var1) {
	//           ++NetworkManager.numReadThreads;
	//       }
	{
		std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
		++NetworkManager::numReadThreads;
	}
	
	// Java has complex control flow with labels - simplified but equivalent logic
	bool threadActive = true;
	while (threadActive)
	{
		// Java: boolean var2 = false; boolean var21 = false;
		bool var2 = false;
		bool var21 = false;
		
		try
		{
			var21 = true;
			var2 = true;
			
			// Java: if(!NetworkManager.isRunning(this.netManager)) {
			//           var2 = false;
			//           var21 = false;
			//           break label187;
			//       }
			if (!NetworkManager::isRunning(netManager))
			{
				var2 = false;
				var21 = false;
				threadActive = false;
				break;
			}
			
			// Java: if(NetworkManager.isServerTerminating(this.netManager)) {
			//           var2 = false;
			//           var21 = false;
			//           break label188;
			//       }
			if (NetworkManager::isServerTerminating(netManager))
			{
				var2 = false;
				var21 = false;
				threadActive = false;
				break;
			}
			
			// Java: while(true) {
			//           if(!NetworkManager.readNetworkPacket(this.netManager)) {
			//               try {
			//                   sleep(100L);
			//                   var21 = false;
			//               } catch (InterruptedException var27) {
			//                   var21 = false;
			//               }
			//               break;
			//           }
			//       }
			while (true)
			{
				if (!NetworkManager::readNetworkPacket(netManager))
				{
					// Java: sleep(100L);
					try
					{
						std::this_thread::sleep_for(std::chrono::milliseconds(100));
					}
					catch (...)
					{
						// Ignore interruption
					}
					var21 = false;
					break;
				}
			}
		}
		catch (const std::exception& e)
		{
			var21 = false;
			// Exception handling - continue loop
		}
		
		// Java: finally block equivalent - decrement counter if var21 was true and var2 was set
		if (var21 && var2)
		{
			{
				std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
				--NetworkManager::numReadThreads;
			}
			var2 = false;  // Prevent double decrement
		}
		
		// Java: if(var2) {
		//           var3 = NetworkManager.threadSyncObject;
		//           synchronized(var3) {
		//               --NetworkManager.numReadThreads;
		//           }
		//       }
		if (var2)
		{
			{
				std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
				--NetworkManager::numReadThreads;
			}
		}
		
		// Continue loop unless we hit exit conditions
		if (!NetworkManager::isRunning(netManager) || NetworkManager::isServerTerminating(netManager))
		{
			threadActive = false;
		}
	}
	
	// Java: var1 = NetworkManager.threadSyncObject;
	//       synchronized(var1) {
	//           --NetworkManager.numReadThreads;
	//       }
	// Final decrement on exit
	{
		std::lock_guard<std::mutex> lock(NetworkManager::threadSyncObject);
		--NetworkManager::numReadThreads;
	}
}
