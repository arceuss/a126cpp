// snprintf_compat.c - provide snprintf/vsnprintf for older MSVC CRTs
#if defined(_MSC_VER)
  #include <stdarg.h>
  #include <stdio.h>

  // MSVC before VS2015 doesn't reliably provide C99 snprintf.
  // Provide local implementations using _vsnprintf.
  int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap)
  {
      int r = _vsnprintf(buf, size, fmt, ap);
      if (r < 0 && size > 0) {
          // Ensure NUL termination on truncation
          buf[size - 1] = '\0';
      }
      return r;
  }

  int snprintf(char *buf, size_t size, const char *fmt, ...)
  {
      va_list ap;
      int r;
      va_start(ap, fmt);
      r = vsnprintf(buf, size, fmt, ap);
      va_end(ap);
      return r;
  }
#endif
